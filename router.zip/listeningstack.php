<?php

    include_once("load.php");


    $ports = file_get_contents("ports.json");
    $avpts = json_decode($ports);
    $socks = [];
    $route = new Routes();
    
    $pasm = new PASM();
    $pasm->recvr_stack($_COOKIE['PHPSESSID']);
    foreach ($avpts as $val) {
        // create a streaming socket, of type TCP/IP
        $sock = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
    
        // set the option to reuse the port
        socket_set_option($sock, SOL_SOCKET, SO_REUSEADDR, 1);
    
        $socks[] = $sock;
        // "bind" the socket to the address to "localhost", on port $port
        // so this means that all connections on this port are now our resposibility to send/recv data, disconnect, etc..
        socket_bind($socks[count($socks)-1], 0, $val);
        socket_listen($socks[count($socks)-1]);
    }

    // start listen for connections

    // create a list of all the clients that will be connected to us..
    // add the listening socket to this list
    $clients = $socks;
   
    while (true) {
        // create a copy, so $clients doesn't get modified by socket_select()
        $read = $clients;
       
        if (count($read) == 0)
            break;
        // get a list of all the clients that have data to be read from
        // if there are no clients with data, go to next iteration
        if (socket_select($read, $write = NULL, $except = NULL, 0) < 1)
            continue;

        // check if there is a client trying to connect
        if (in_array($sock, $read)) {
            // accept the client, and add him to the $clients array
            $clients[] = $newsock = socket_accept($sock);

            // send the client a welcome message
            socket_write($newsock,
            "There are " . count($clients) . " client(s) connected to the server\n");
            
            socket_getpeername($newsock, $ip);
            echo "New client connected: {$ip}\n";
           
            // remove the listening socket from the clients-with-data array
            $key = array_search($sock, $read);
            unset($read[$key]);
        }
       
        // loop through all the clients that have data to read from
        foreach ($read as $read_sock) {
            $datab = "";
            $data = "";
            // socket_read while show errors when the client is disconnected, so silence the error messages
            while ($datab = @socket_read($read_sock, 1024, PHP_NORMAL_READ))
                $data .= $datab;
           
            // check if the client is disconnected
            if ($data === false) {
                // remove client for $clients array
                $key = array_search($read_sock, $clients);
                unset($clients[$key]);
                echo "Client Disconnected.\n";
                // continue to the next client to read from, if any
                continue;
            }
           
            // trim off the trailing/beginning white spaces
            $data = trim($data);
           
            // check if there is any data after trimming off the spaces
            if (!empty($data)) {
           
                // send this to all the clients in the $clients array (except the first one, which is a listening socket)
                foreach ($clients as $send_sock) {
               
                    // if its the listening sock or the client that we got the message from, go to the next one in the list
                    if ($send_sock == $sock || $send_sock == $read_sock)
                        continue;
                   
                    // write the message to the client -- add a newline character to the end of the message
                    socket_write($send_sock, $data."\n");
                   
                } // end of broadcast foreach
               
            }
           
        } // end of reading foreach
    }

    // close the listening socket
    socket_close($sock);
?>