<?php

include_once('userclass.php');
include_once('pasm.php');
include_once('routes.php');
include_once('crud.php');